require("./Databases/module.js")

//========== Setting Owner ==========//
global.no = "15873323950"
global.owner = "*SKYZO D.E.V"
global.bot = "XNAF CRASH"
global.v = "1.0.0"
global.welcome = false
global.autoread = false
global.anticall = true

//========= Setting Url Foto =========//
global.image = "https://e.top4top.io/p_3190lbz9s0.jpg"

global.msg = {
"error": "Maaf Adanya Sistem Error Pada Fitur Ini!!",
"done": "Berhasil🕊", 
"wait": "Wait To Proses🕊", 
"owner": "`You Now Owner`", 
"developer": "`You Now Development`"
}










































































global.own = "SKYZO D.E.V"
global.log = "❒"
global.ch = "https://whatsapp.com/channel/0029VahUbrs90x2wGeaWAc14"
global.bot = "XNAF - CRASH"
global.ver = "1.0.0"


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})